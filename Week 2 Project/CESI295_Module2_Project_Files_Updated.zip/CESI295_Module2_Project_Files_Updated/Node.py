#Name: Your name
#Date: Your date

class Node:
    def __init__(self, initial_data=None):
        self.data = initial_data
        self.next = None